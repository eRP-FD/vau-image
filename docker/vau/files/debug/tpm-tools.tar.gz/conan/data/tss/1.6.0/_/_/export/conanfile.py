#!/usr/bin/env python3

###################################################################################################

from conans import AutoToolsBuildEnvironment
from conans import ConanFile
from conans import tools
from conans.errors import ConanException

###################################################################################################

import os
import shutil

###################################################################################################

class TssConan(ConanFile):

    # custom properties for usage by this specific recipe's code, not by the Conan SDK

    _repository_name = 'ibmtss'

    _repository_url = 'https://github.com/kgoldman/{name}.git'.format(name=_repository_name)

    _source_subfolder = 'src'

    _linux_build_requirements = ['autoconf/2.69',
                                 'automake/1.16.3',
                                 'libtool/2.4.6',
                                 'pkgconf/1.7.3']

    _linux_run_requirements = ['openssl/1.1.1i']

    _windows_build_requirements = 'msys2/20200517'

    _windows_gcc_executable = 'gcc.exe'

    _windows_bash_executable = 'bash.exe'

    _windows_run_requirements = ['openssl-devel']

    _windows_run_dependencies = ['msys-2.0.dll',
                                 'msys-gcc_s-seh-1.dll',
                                 'msys-crypto-1.1.dll',
                                 'msys-z.dll']

    _windows_build_flags = ['CFLAGS="-DTPM_POSIX"',
                            'LDFLAGS="-no-undefined"']

    _windows_source_files_patches = \
        {'libtool': ('_spawnv', 'spawnv'),
         os.path.join('utils12', 'ekutils12.c'): ('extern int tssUtilsVerbose',
                                                  'int tssUtilsVerbose = TRUE')}

    _autotools = None

    # Conan properties, used by the Conan SDK

    name = 'tss'

    homepage = 'https://sourceforge.net/projects/ibmtpm20tss'

    description = 'This is a user space TSS for TPM 2.0. It implements the ' \
                  'functionality equivalent to (but not API compatible with) ' \
                  'the TCG TSS working group\'s ESAPI, SAPI, and TCTI API\'s ' \
                  '(and perhaps more) but with a hopefully simpler interface.'

    version = '1.6.0'

    author = 'Theodor Serbana <theodor.serbana@ibm.com>'

    license = 'proprietary'

    url = 'https://github.ibmgcloud.net/eRp/conan-recipes'

    generators = 'pkg_config'

    settings = 'os', 'compiler', 'build_type', 'arch'

    options = {'with_tpm_1_2': [True, False],
               'with_tpm_2_0': [True, False],
               'with_hardware_tpm': [True, False]}

    default_options = {'openssl:shared': True,
                       'with_tpm_1_2': True,
                       'with_tpm_2_0': True,
                       'with_hardware_tpm': True}

    def _require_packages(self, packages, requirement_type):
        if not isinstance(packages, list):
            if requirement_type == 'build':
                self.build_requires(packages)
            elif requirement_type == 'run':
                self.requires(packages)
        else:
            for package in packages:
                if requirement_type == 'build':
                    self.build_requires(package)
                elif requirement_type == 'run':
                    self.requires(package)

    def _move_repository_contents_into_cwd(self):
        for file in os.scandir(self._repository_name):
            shutil.move(file.path, os.getcwd())

        os.rmdir(self._repository_name)

    def _check_prerequisites(self):
        if ((self.settings.os != 'Linux' and self.settings.os != 'Windows') or
               (self.settings.compiler != 'gcc' and
                self.settings.compiler != 'clang' and
                self.settings.compiler != 'Visual Studio') or
            (self.settings.build_type != 'Debug' and self.settings.build_type != 'Release') or
            (self.settings.arch != 'x86' and self.settings.arch != 'x86_64')):
                raise ConanException('{name} is available only for: Linux/Windows/gcc/msvc/clang/'
                                     'Debug/Release/x86_64/x86'.format(name=self.name))

    def _get_configuration_arguments(self):
        # start with a basic argument list and enrich it depending on options
        #
        arguments = []

        if tools.os_info.is_windows:
            arguments.append('--prefix={path}'.format(path=tools.unix_path(self.package_folder)))

        if self.settings.build_type == 'Debug':
            arguments.append('--enable-debug')

        if not self.options.with_tpm_1_2:
            arguments.append('--disable-tpm-1.2')

        if not self.options.with_tpm_2_0:
            arguments.append('--disable-tpm-2.0')

        if not self.options.with_hardware_tpm:
            arguments.append('--disable-hwtpm')

        return arguments

    def _windows_patch_source_files(self):
        if not tools.os_info.is_windows:
            raise ConanException('Source file patching should only be done on Windows')

        for file, patch in self._windows_source_files_patches.items():
            tools.replace_in_file(file, patch[0], patch[1])

    def _get_windows_msys2_bin_path(self):
        if not tools.os_info.is_windows:
            raise ConanException('msys2 should be needed only on Windows')

        bin_path = self.deps_env_info['msys2'].MSYS_BIN
        if not bin_path:
            raise ConanException('Cannot find MSYS_BIN env var defined by msys2')
        if not os.path.exists(bin_path):
            raise ConanException('msys2 path MSYS_BIN `{path}` does '
                                 'not exist'.format(path=bin_path))

        return bin_path

    def _get_autotools(self):
        if self._autotools:
            return self._autotools

        self._autotools = AutoToolsBuildEnvironment(self, win_bash=tools.os_info.is_windows)

        self.run('autoreconf -ivf', win_bash=tools.os_info.is_windows)

        if tools.os_info.is_windows:
            self.run('pacman --noconfirm --needed -S {requirements}'.format(
                             requirements=' '.join(self._windows_run_requirements)),
                     win_bash=True)

            self.run('./configure {args} CC={compiler}'.format(
                             args=' '.join(self._get_configuration_arguments()),
                             compiler=tools.unix_path(os.path.join(
                                                          self._get_windows_msys2_bin_path(),
                                                          self._windows_gcc_executable))),
                     win_bash=True)

            self._windows_patch_source_files()
        else:
            self._autotools.configure(args=self._get_configuration_arguments())

        return self._autotools

    def init(self):
        if tools.os_info.is_windows:
            os.environ['CONAN_USER_HOME_SHORT'] = 'None'

    def build_requirements(self):
        if tools.os_info.is_linux:
            self._require_packages(self._linux_build_requirements, 'build')
        elif tools.os_info.is_windows:
            self._require_packages(self._windows_build_requirements, 'build')
        else:
            raise ConanException('Host platform is neither Linux nor Windows')

    def requirements(self):
        if tools.os_info.is_linux:
            self._require_packages(self._linux_run_requirements, 'run')

    def source(self):
        self.output.info('Cloning {name} from: {url}'.format(name=self._repository_name,
                                                             url=self._repository_url))
        
        # try to clone the repository.
        # if there's any failure, let it propagate, but show a pretty error message
        #
        try:
            self.run('git clone --progress --verbose {url}'.format(url=self._repository_url))
            self.run('git config advice.detachedHead false', cwd=self._repository_name)
            self.run('git checkout tags/v{version}'.format(version=self.version),
                     cwd=self._repository_name)
        except ConanException:
            self.output.info('Unable to clone {name}. '
                             'See errors below.'.format(name=self._repository_name))
            raise

    def build(self):
        self._check_prerequisites()
        self._move_repository_contents_into_cwd()

        env_vars = None
        if tools.os_info.is_windows:
            env_vars = {'CONAN_BASH_PATH': os.path.join(self._get_windows_msys2_bin_path(),
                                                        self._windows_bash_executable)}
            with tools.environment_append(env_vars):
                autotools = self._get_autotools()
                autotools.make(args=self._windows_build_flags if tools.os_info.is_windows else [])

    def package(self):
        self._check_prerequisites()

        autotools = self._get_autotools()
        autotools.install()

        if tools.os_info.is_windows:
            for dependency in self._windows_run_dependencies:
                self.copy(dependency,
                          src=self._get_windows_msys2_bin_path(),
                          dst='bin',
                          keep_path=False)

    def package_info(self):
        self.cpp_info.libs = tools.collect_libs(self)
        self.cpp_info.defines = ['TPM_WINDOWS' if tools.os_info.is_windows else 'TPM_POSIX']

###################################################################################################
